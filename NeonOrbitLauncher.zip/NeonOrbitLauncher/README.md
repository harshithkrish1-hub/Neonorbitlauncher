# NeonOrbit Launcher

A beginner-friendly Android launcher starter project designed for a landscape tablet such as the Xiaomi Pad 8. It uses native Android views and Kotlin, with no third-party UI libraries.

## Features
- Neon animated grid background with three accent palettes
- Clock and date
- Battery percentage and charging state
- Android memory usage dashboard (system-wide figures; not GPU temperature or exact game FPS)
- Current weather for Chennai using Open-Meteo; it does not request location permission
- Roblox launch button (Blox Fruits is inside Roblox)
- ChatGPT app shortcut, with a web fallback
- App list / app drawer dialog
- Android Settings shortcut
- Split-screen instructions for HyperOS / Android
- Android HOME intent filter so it can be selected as the default home app

## Requirements
- Android Studio (current stable release)
- Android SDK Platform 35
- JDK 17 (Android Studio's bundled JDK is usually suitable)
- Internet connection for the first Gradle sync and weather requests

## Build the APK
1. Download and unzip `NeonOrbitLauncher.zip`.
2. Open Android Studio.
3. Choose **Open** and select the extracted `NeonOrbitLauncher` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to finish and install any requested Android SDK components.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build completes, use the notification's **locate** link. The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Install on the Xiaomi Pad 8
1. Copy `app-debug.apk` to the tablet, or install it over USB from Android Studio.
2. If sideloading, allow your file manager to install unknown apps for this installation, then install the APK.
3. Press Home. Choose **NeonOrbit** and select **Always** if you want it as the default launcher. HyperOS menu wording can vary.
4. To switch back, open Settings and search for **Default apps** or **Home app / Launcher**, then select the Xiaomi system launcher.

## Important Android / HyperOS limitations
- This project provides source code, not a prebuilt APK. It has not been compiled or tested on physical hardware in this environment.
- Weather is hard-coded to Chennai coordinates for the starter version. It requires internet and may show an offline message if the service is unreachable.
- The ChatGPT button opens the ChatGPT app if its package is present, otherwise it opens chatgpt.com. It does not embed an AI model or access private ChatGPT conversation data.
- The Roblox button launches Roblox. It cannot deep-link reliably to a specific Roblox experience because experience URLs/launch handling can change; select Blox Fruits in Roblox.
- Android/HyperOS controls split-screen. This launcher explains the process but cannot force arbitrary apps into split-screen or guarantee that a game supports it.
- The memory number is general Android memory information, not a precise measure of memory used by this launcher or Roblox. The app does not read CPU/GPU temperatures or FPS.
- The manifest uses `QUERY_ALL_PACKAGES` to populate the app grid. Google Play restricts broad package visibility; this project is intended for personal sideloading and may need a narrower package visibility setup for Play Store publication.
- The three palettes are generated backgrounds; importing personal wallpaper images is not implemented in this starter version.

## Project structure
- `app/src/main/java/com/harshith/neonnexus/MainActivity.kt` — UI, animation, app actions, weather and telemetry
- `app/src/main/AndroidManifest.xml` — launcher/home registration and internet permission
- `app/src/main/res/values/styles.xml` — system theme
- `app/build.gradle.kts` — Android build configuration

## Troubleshooting
- **Gradle sync fails:** check Android Studio's JDK is 17 and install SDK Platform 35 in SDK Manager.
- **Roblox button says not installed:** install Roblox from Google Play, then reopen the launcher.
- **Launcher doesn't appear under Home apps:** build/install succeeded only if the app is installed; try restarting the tablet or opening the app once.
- **Weather stays offline:** check Wi-Fi and retry by tapping the weather card.
