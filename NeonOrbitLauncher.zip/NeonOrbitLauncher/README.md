# NeonOrbit Launcher 2.0

A tablet-friendly Android home launcher with a searchable installed-app drawer and four animated ambient scenes.

## Build
Open this folder in Android Studio and build `app` > `assembleDebug`, or run `gradle assembleDebug` with Android SDK 35 installed.

## Set as default
Install the APK, press Home, and choose NeonOrbit. If Android does not prompt, open Settings > Apps > Default apps > Home app and select NeonOrbit.

Note: this source uses application ID `com.neonorbit.launcher`. If you already installed a differently packaged NeonOrbit APK, Android treats this as a separate app; don't uninstall the old one until you have tested this build.
