package com.neonorbit.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 16, 29)
    private val panel = Color.argb(218, 28, 34, 53)
    private val text = Color.rgb(239, 238, 249)
    private val muted = Color.rgb(164, 169, 190)
    private val accent = Color.rgb(191, 169, 255)
    private var scene = 0
    private lateinit var root: FrameLayout
    private lateinit var wallpaper: SceneView
    private var drawerOpen = false
    private val prefs by lazy { getSharedPreferences("orbit", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.rgb(9, 12, 22)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        scene = prefs.getInt("scene", 0)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun label(value: String, size: Float, color: Int = text, bold: Boolean = false): TextView =
        TextView(this).apply { this.text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }

    private fun base(): FrameLayout {
        root = FrameLayout(this)
        wallpaper = SceneView(this)
        wallpaper.scene = scene
        root.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        return root
    }

    private fun showHome() {
        drawerOpen = false
        val frame = base()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(26), dp(48), dp(26), dp(20))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("NEONORBIT", 13f, accent, true))
        val spacer = View(this); top.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        val settings = label("◌", 27f, text)
        settings.setPadding(dp(12), 0, dp(8), 0)
        settings.setOnClickListener { showSettings() }
        top.addView(settings)
        column.addView(top, LinearLayout.LayoutParams(-1, dp(40)))

        val clockBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(34), 0, dp(20)) }
        val time = label(SimpleDateFormat("h:mm", Locale.getDefault()).format(Date()), 58f, text, true)
        val date = label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 15f, muted)
        clockBox.addView(time); clockBox.addView(date)
        column.addView(clockBox)

        val note = label("A little space to breathe.", 15f, text)
        note.setPadding(0, dp(18), 0, dp(14))
        column.addView(note)

        val section = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        section.addView(label("YOUR SPACE", 11f, muted, true))
        val push = View(this); section.addView(push, LinearLayout.LayoutParams(0, 1, 1f))
        val allApps = label("All apps  ↗", 13f, accent, true)
        allApps.setOnClickListener { showDrawer() }
        section.addView(allApps)
        column.addView(section, LinearLayout.LayoutParams(-1, dp(36)))

        val favorites = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
        val common = listOf("Settings", "Chrome", "YouTube", "Camera")
        common.forEach { name ->
            val app = findApp(name)
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                background = rounded(Color.argb(150, 31, 37, 58), 20)
                setPadding(dp(7), dp(12), dp(7), dp(12))
            }
            val icon = ImageView(this)
            if (app != null) icon.setImageDrawable(app.loadIcon(packageManager)) else icon.setImageResource(android.R.drawable.sym_def_app_icon)
            tile.addView(icon, LinearLayout.LayoutParams(dp(36), dp(36)))
            val title = label(app?.loadLabel(packageManager)?.toString() ?: name, 10f, text)
            title.gravity = Gravity.CENTER
            title.maxLines = 1
            tile.addView(title, LinearLayout.LayoutParams(-1, dp(24)))
            tile.setOnClickListener { if (app != null) launch(app) else if (name == "Settings") startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) else showDrawer() }
            val lp = LinearLayout.LayoutParams(0, dp(88), 1f); lp.setMargins(dp(4), 0, dp(4), 0)
            favorites.addView(tile, lp)
        }
        column.addView(favorites)

        val bottomSpace = View(this); column.addView(bottomSpace, LinearLayout.LayoutParams(1, 0, 1f))
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.argb(210, 29, 35, 54), 26)
            setPadding(dp(18), dp(10), dp(18), dp(10))
        }
        val hint = label("⌕   Search your apps", 15f, muted)
        dock.addView(hint, LinearLayout.LayoutParams(0, dp(34), 1f))
        val grid = label("▦", 24f, accent)
        dock.addView(grid)
        dock.setOnClickListener { showDrawer() }
        column.addView(dock, LinearLayout.LayoutParams(-1, dp(58)))
        frame.addView(column, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    private fun showSettings() {
        val choices = arrayOf("Night forest", "Greenhouse", "Sunset haze", "Cosmic dusk")
        AlertDialog.Builder(this)
            .setTitle("Make it yours")
            .setItems(choices) { _, which ->
                scene = which; prefs.edit().putInt("scene", scene).apply()
                showHome()
            }
            .setNeutralButton("Set as default launcher") { _, _ ->
                try { startActivity(Intent(android.provider.Settings.ACTION_HOME_SETTINGS)) }
                catch (_: Exception) { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            }
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showDrawer() {
        drawerOpen = true
        val frame = base()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(42), dp(20), dp(16))
            background = rounded(Color.argb(238, 13, 17, 31), 0)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = label("All apps", 28f, text, true)
        header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        val close = label("✕", 21f, muted); close.setPadding(dp(12), dp(8), dp(8), dp(8)); close.setOnClickListener { showHome() }
        header.addView(close)
        column.addView(header)
        val search = EditText(this).apply {
            hint = "Search installed apps"; setHintTextColor(muted); setTextColor(text); textSize = 15f
            singleLine = true; setPadding(dp(16), 0, dp(16), 0)
            background = rounded(Color.rgb(32, 38, 58), 18)
        }
        val searchLp = LinearLayout.LayoutParams(-1, dp(52)); searchLp.setMargins(0, dp(12), 0, dp(12))
        column.addView(search, searchLp)
        val scroll = ScrollView(this)
        val grid = GridLayout(this).apply { columnCount = if (resources.configuration.screenWidthDp > 600) 6 else 4; useDefaultMargins = false }
        scroll.addView(grid)
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        frame.addView(column, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        fun populate(query: String) {
            grid.removeAllViews()
            val apps = getLaunchableApps().filter { it.loadLabel(packageManager).toString().contains(query, true) }
                .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
            val width = (resources.displayMetrics.widthPixels - dp(40)) / grid.columnCount
            apps.forEach { app ->
                val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(10), dp(4), dp(10)) }
                val icon = ImageView(this); icon.setImageDrawable(app.loadIcon(packageManager))
                tile.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
                val name = label(app.loadLabel(packageManager).toString(), 11f, text)
                name.gravity = Gravity.CENTER; name.maxLines = 2; name.ellipsize = android.text.TextUtils.TruncateAt.END
                tile.addView(name, LinearLayout.LayoutParams(-1, dp(34)))
                tile.setOnClickListener { launch(app) }
                grid.addView(tile, ViewGroup.LayoutParams(width, dp(92)))
            }
            if (apps.isEmpty()) {
                val empty = label("No apps found", 14f, muted)
                grid.addView(empty, ViewGroup.LayoutParams(-1, dp(48)))
            }
        }
        populate("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun getLaunchableApps(): List<ApplicationInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0).map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
    }
    private fun findApp(name: String): ApplicationInfo? = getLaunchableApps().firstOrNull {
        it.loadLabel(packageManager).toString().contains(name, true)
    }
    private fun launch(app: ApplicationInfo) {
        val i = packageManager.getLaunchIntentForPackage(app.packageName)
        if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }
    }
    override fun onBackPressed() { if (drawerOpen) showHome() else super.onBackPressed() }

    inner class SceneView(context: Context) : View(context) {
        var scene = 0
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stars = (0..85).map { Star(Math.random().toFloat(), Math.random().toFloat(), (1 + Math.random() * 2).toFloat(), Math.random().toFloat() * 6.28f) }
        private var tick = 0f
        private val runnable = object : Runnable {
            override fun run() { tick += 0.035f; invalidate(); postDelayed(this, 70) }
        }
        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null); post(runnable) }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat(); val h = height.toFloat()
            val colors = when(scene) {
                1 -> intArrayOf(Color.rgb(13, 47, 45), Color.rgb(22, 75, 66), Color.rgb(8, 20, 28))
                2 -> intArrayOf(Color.rgb(95, 59, 91), Color.rgb(191, 105, 98), Color.rgb(31, 29, 53))
                3 -> intArrayOf(Color.rgb(28, 32, 71), Color.rgb(67, 55, 103), Color.rgb(13, 17, 33))
                else -> intArrayOf(Color.rgb(27, 37, 57), Color.rgb(54, 48, 79), Color.rgb(12, 16, 29))
            }
            paint.shader = LinearGradient(0f, 0f, w * .8f, h, colors, null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, paint); paint.shader = null
            // Soft ambient glow
            paint.shader = RadialGradient(w * .75f, h * .24f, w * .6f,
                intArrayOf(Color.argb(52, 186, 165, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, paint); paint.shader = null
            stars.forEach {
                val y = (it.y * h + sin(tick + it.phase) * 5f + h) % h
                val alpha = (75 + 100 * (0.5 + 0.5 * kotlin.math.sin(tick + it.phase))).toInt().coerceIn(20, 190)
                paint.color = Color.argb(alpha, 223, 225, 255)
                c.drawCircle(it.x * w, y, it.r, paint)
            }
            if (scene == 0 || scene == 3) {
                paint.color = Color.argb(28, 190, 175, 255)
                c.drawCircle(w * .72f, h * .38f, w * .20f, paint)
                paint.color = Color.argb(34, 215, 210, 255)
                c.drawCircle(w * .72f, h * .38f, w * .14f, paint)
            }
            if (scene == 1) {
                paint.color = Color.argb(30, 100, 210, 154)
                for (i in 0..8) {
                    val x = (i * w / 8f) + sin(tick + i) * 7f
                    paint.strokeWidth = dp(2).toFloat()
                    c.drawLine(x, h * .38f, x + sin(tick + i) * 20, h, paint)
                }
            }
        }
        private fun sin(v: Float) = kotlin.math.sin(v)
        data class Star(val x: Float, val y: Float, val r: Float, val phase: Float)
    }
}
