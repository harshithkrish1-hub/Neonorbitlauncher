package com.harshith.neonorbit

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.sin

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView
    private lateinit var batteryText: TextView
    private lateinit var memoryText: TextView
    private lateinit var weatherText: TextView
    private lateinit var backdrop: NeonBackdrop
    private var palette = 0
    private val palettes = arrayOf(
        intArrayOf(0xFF07101F.toInt(), 0xFF102844.toInt(), 0xFF00E5FF.toInt()),
        intArrayOf(0xFF10081F.toInt(), 0xFF2B1245.toInt(), 0xFFB967FF.toInt()),
        intArrayOf(0xFF071A13.toInt(), 0xFF123B35.toInt(), 0xFF48FFB0.toInt())
    )

    private val tick = object : Runnable {
        override fun run() {
            if (::clockText.isInitialized) {
                clockText.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                dateText.text = SimpleDateFormat("EEEE  •  d MMMM", Locale.getDefault()).format(Date())
                updateMemory()
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null || !::batteryText.isInitialized) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            val pct = (level * 100 / scale).coerceIn(0, 100)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            batteryText.text = "$pct%  •  ${if (charging) "CHARGING" else "ON BATTERY"}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF050914.toInt()
        window.navigationBarColor = 0xFF050914.toInt()
        buildUi()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        handler.post(tick)
        refreshWeather()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun buildUi() {
        val frame = FrameLayout(this)
        backdrop = NeonBackdrop(this, palettes[palette])
        frame.addView(backdrop, FrameLayout.LayoutParams(-1, -1))

        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(24))
        }
        scroll.addView(page)
        frame.addView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = column(0).apply {
            addView(label("N E O N   N E X U S", 13, palettes[palette][2], true))
            addView(label("PERSONAL COMMAND DECK", 10, 0xFF9EB4CB.toInt(), false).apply { setPadding(0, dp(4), 0, 0) })
        }
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(chip("PAD 8  /  ONLINE"))
        page.addView(top)
        page.addView(space(16))

        val hero = panel(18).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heroLeft = column(0)
        heroLeft.addView(label("SYSTEM READY", 11, palettes[palette][2], true))
        clockText = label("--:--:--", 42, 0xFFF4FAFF.toInt(), true)
        clockText.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        heroLeft.addView(clockText)
        dateText = label("Loading date…", 13, 0xFFB4C7DB.toInt(), false)
        heroLeft.addView(dateText)
        heroLeft.addView(space(12))
        heroLeft.addView(label("Your games. Your tools. One cockpit.", 13, 0xFFE0EEFA.toInt(), false))
        hero.addView(heroLeft, LinearLayout.LayoutParams(0, -2, 1f))
        val orb = TextView(this).apply {
            text = "✦"
            textSize = 52f
            gravity = Gravity.CENTER
            setTextColor(palettes[palette][2])
            background = rounded(0x2235E7FF, 100, 0xAA35E7FF.toInt(), 1)
        }
        hero.addView(orb, LinearLayout.LayoutParams(dp(92), dp(92)))
        page.addView(hero)
        page.addView(space(14))

        page.addView(sectionTitle("QUICK DEPLOY", "GAMES & TOOLS"))
        page.addView(space(8))
        val games = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        games.addView(actionCard("◈", "ROBLOX", "Launch Blox Fruits", palettes[palette][2]) { launchRoblox() }, LinearLayout.LayoutParams(0, dp(112), 1f))
        games.addView(spaceHorizontal(10))
        games.addView(actionCard("⌘", "AI ASSISTANT", "Open ChatGPT", 0xFFB967FF.toInt()) { openAssistant() }, LinearLayout.LayoutParams(0, dp(112), 1f))
        games.addView(spaceHorizontal(10))
        games.addView(actionCard("▦", "APP GRID", "Find any app", 0xFF48FFB0.toInt()) { showAppDrawer() }, LinearLayout.LayoutParams(0, dp(112), 1f))
        page.addView(games)
        page.addView(space(14))

        page.addView(sectionTitle("LIVE TELEMETRY", "DEVICE STATUS"))
        page.addView(space(8))
        val telemetry = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val batteryCard = infoCard("BATTERY", "Reading…", "◉", palettes[palette][2]); batteryText = batteryCard.tag as TextView
        val ramCard = infoCard("MEMORY", "Reading…", "▤", 0xFFB967FF.toInt()); memoryText = ramCard.tag as TextView
        val weatherCard = infoCard("WEATHER · CHENNAI", "Fetching…", "☼", 0xFFFFD166.toInt()); weatherText = weatherCard.tag as TextView
        telemetry.addView(batteryCard, LinearLayout.LayoutParams(0, dp(94), 1f))
        telemetry.addView(spaceHorizontal(10))
        telemetry.addView(ramCard, LinearLayout.LayoutParams(0, dp(94), 1f))
        telemetry.addView(spaceHorizontal(10))
        telemetry.addView(weatherCard, LinearLayout.LayoutParams(0, dp(94), 1f))
        page.addView(telemetry)
        page.addView(space(14))

        page.addView(sectionTitle("FIELD CONTROLS", "PERSONALIZE & MULTITASK"))
        page.addView(space(8))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(controlButton("✧  Change glow", "Cycle neon palettes") { cyclePalette() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(spaceHorizontal(10))
        controls.addView(controlButton("▣  Split-screen guide", "Android multitasking") { showSplitGuide() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(spaceHorizontal(10))
        controls.addView(controlButton("⚙  Settings", "System controls") { openSettings() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        page.addView(controls)
        page.addView(space(14))
        page.addView(panel(14).apply {
            addView(label("MISSION NOTE", 10, palettes[palette][2], true))
            addView(space(5))
            addView(label("Blox Fruits lives inside Roblox. Open Roblox, choose Blox Fruits, and use Android Recents to place it beside another app.", 12, 0xFFD2DFED.toInt(), false))
        })
        page.addView(space(12))
        page.addView(label("NEON NEXUS  •  VERSION 1.0  •  BUILT FOR LANDSCAPE", 9, 0xFF71869E.toInt(), true).apply { gravity = Gravity.CENTER })

        setContentView(frame)
    }

    private fun sectionTitle(left: String, right: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(label(left, 11, 0xFFEAF6FF.toInt(), true), LinearLayout.LayoutParams(0, -2, 1f))
        addView(label(right, 9, 0xFF8299B2.toInt(), true))
    }

    private fun actionCard(symbol: String, title: String, subtitle: String, accent: Int, action: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(12), dp(10), dp(10))
        background = rounded(0xCC0A1728.toInt(), 16, accent, 1)
        isClickable = true; isFocusable = true; setOnClickListener { action() }
        addView(label(symbol, 23, accent, true))
        addView(space(5))
        addView(label(title, 11, 0xFFF4FAFF.toInt(), true))
        addView(label(subtitle, 10, 0xFF9CB2C9.toInt(), false).apply { setPadding(0, dp(3), 0, 0) })
    }

    private fun infoCard(title: String, value: String, symbol: String, accent: Int): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(10), dp(8))
            background = rounded(0xCC0A1728.toInt(), 14, 0x554C7699, 1)
        }
        box.addView(label("$symbol  $title", 9, accent, true))
        val valueView = label(value, 13, 0xFFF0F7FF.toInt(), true).apply { setPadding(0, dp(9), 0, 0) }
        box.addView(valueView)
        box.tag = valueView
        if (title.startsWith("WEATHER")) box.setOnClickListener { refreshWeather() }
        return box
    }

    private fun controlButton(title: String, desc: String, action: () -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(7), dp(10), dp(7))
        background = rounded(0xCC0A1728.toInt(), 13, 0x665C8BA8, 1)
        isClickable = true; isFocusable = true; setOnClickListener { action() }
        addView(label(title, 11, 0xFFEAF6FF.toInt(), true))
        addView(label(desc, 9, 0xFF8EA7C0.toInt(), false))
    }

    private fun chip(text: String) = TextView(this).apply {
        this.text = text; textSize = 9f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF8DF5FF.toInt())
        setPadding(dp(10), dp(8), dp(10), dp(8)); background = rounded(0x3325DFFF, 30, 0x6635E7FF, 1)
    }

    private fun panel(pad: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        background = rounded(0xD90A1728.toInt(), 18, 0x7735E7FF, 1)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        includeFontPadding = true
    }

    private fun column(padding: Int) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(padding, 0, padding, 0) }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun spaceHorizontal(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Int, stroke: Int, strokeDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(strokeDp), stroke)
    }

    private fun cyclePalette() {
        palette = (palette + 1) % palettes.size
        backdrop.colors = palettes[palette]
        buildUi()
        refreshWeather()
    }

    private fun updateMemory() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val usedGb = (mi.totalMem - mi.availMem) / (1024.0 * 1024 * 1024)
        val totalGb = mi.totalMem / (1024.0 * 1024 * 1024)
        memoryText.text = String.format(Locale.getDefault(), "%.1f / %.1f GB", usedGb, totalGb)
    }

    private fun refreshWeather() {
        if (!::weatherText.isInitialized) return
        weatherText.text = "Updating…"
        thread {
            var result = "Offline · tap to retry"
            var conn: HttpURLConnection? = null
            try {
                // Default city is Chennai; no location permission or personal location is collected.
                conn = (URL("https://api.open-meteo.com/v1/forecast?latitude=13.0827&longitude=80.2707&current=temperature_2m,relative_humidity_2m,weather_code&timezone=Asia%2FKolkata").openConnection() as HttpURLConnection)
                conn.connectTimeout = 5000; conn.readTimeout = 5000; conn.requestMethod = "GET"
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val current = json.getJSONObject("current")
                val temp = current.optDouble("temperature_2m", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val code = current.optInt("weather_code", -1)
                result = String.format(Locale.getDefault(), "%.0f°C · %s", temp, weatherDescription(code)) + if (humidity >= 0) " · $humidity% RH" else ""
            } catch (_: Exception) { }
            finally { conn?.disconnect() }
            runOnUiThread { if (::weatherText.isInitialized) weatherText.text = result }
        }
    }

    private fun weatherDescription(code: Int): String = when (code) {
        0 -> "Clear"; 1, 2 -> "Mostly clear"; 3 -> "Cloudy"; 45, 48 -> "Fog"
        51, 53, 55, 56, 57 -> "Drizzle"; 61, 63, 65, 66, 67 -> "Rain"
        71, 73, 75, 77 -> "Snow"; 80, 81, 82 -> "Showers"; 85, 86 -> "Snow showers"
        95, 96, 99 -> "Thunderstorm"; else -> "Conditions unavailable"
    }

    private fun launchRoblox() {
        val launch = packageManager.getLaunchIntentForPackage("com.roblox.client")
        if (launch != null) startActivity(launch) else showMessage("Roblox isn't installed", "Install Roblox from Google Play. Blox Fruits is a game inside Roblox, not a separate app.")
    }

    private fun openAssistant() {
        val appIntent = packageManager.getLaunchIntentForPackage("com.openai.chatgpt")
        if (appIntent != null) startActivity(appIntent)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com")))
    }

    private fun openSettings() { startActivity(Intent(Settings.ACTION_SETTINGS)) }

    private fun showSplitGuide() {
        showMessage("Split-screen on Xiaomi Pad 8", "1. Open Roblox from this launcher.\n2. Open Android Recents using the gesture bar or navigation button.\n3. Tap and hold the Roblox app card or its app icon.\n4. Choose Split screen if HyperOS offers it.\n5. Pick the second app.\n\nMenu names vary by HyperOS version. Some games or apps may refuse split-screen, and Android does not let this launcher force every app into it.")
    }

    private fun showAppDrawer() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }
        val names = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("APP GRID  ·  ${apps.size} APPS").setItems(names) { _, which ->
            try { startActivity(pm.getLaunchIntentForPackage(apps[which].activityInfo.packageName)) }
            catch (_: Exception) { showMessage("Can't open app", "Android did not provide a launch action for this app.") }
        }.setNegativeButton("Close", null).show()
    }

    private fun showMessage(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Got it", null).show()
    }
}

private class NeonBackdrop(context: Context, var colors: IntArray) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val density = resources.displayMetrics.density
    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        paint.shader = LinearGradient(0f, 0f, w, h, intArrayOf(colors[0], colors[1], 0xFF050914.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
        paint.color = colors[2]; paint.alpha = 24
        val spacing = 34f * density
        var x = -spacing + (phase % spacing)
        while (x < w) { canvas.drawLine(x, 0f, x, h, paint); x += spacing }
        var y = -spacing + (phase * 0.55f % spacing)
        while (y < h) { canvas.drawLine(0f, y, w, y, paint); y += spacing }
        paint.alpha = 18
        val glowX = w * (0.5f + 0.35f * sin(phase / (90f * density)))
        canvas.drawCircle(glowX, h * 0.18f, 120f * density, paint)
        phase += 0.7f * density
        postInvalidateDelayed(33)
    }
}
